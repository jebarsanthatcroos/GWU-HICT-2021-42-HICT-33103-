package com.example.hict31033_week7.data

data class DogResponse(
    val message: List<String>,
    val status: String
)