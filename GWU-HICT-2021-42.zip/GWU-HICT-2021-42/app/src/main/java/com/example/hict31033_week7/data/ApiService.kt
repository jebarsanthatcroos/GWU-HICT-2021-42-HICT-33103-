package com.example.hict31033_week7.data

import retrofit2.http.GET

interface ApiService {
    // GET request එක Dog API එකට යන්න
    @GET("breeds/image/random/10")
    suspend fun getRandomDogImages(): DogResponse
}